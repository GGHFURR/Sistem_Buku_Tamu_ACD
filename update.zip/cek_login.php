<?php
// aktifkan session
session_start();

// panggil koneksi database
include "koneksi.php";

@$pass = md5($_POST['password']);
$username = mysqli_real_escape_string($koneksi, $_POST['username']);
$password = mysqli_real_escape_string($koneksi, $pass);

$login = mysqli_query($koneksi, "SELECT * FROM tuser2 WHERE username = '$username' AND password ='$password' AND status ='Aktif' ");

if (!$login) {
    // Jika terjadi kesalahan pada kueri SQL
    echo "Error: " . mysqli_error($koneksi);
    exit(); // Keluar dari skrip jika terjadi kesalahan
}

$data = mysqli_fetch_array($login);

// uji jika username dan password ditemukan sesuai
if (!empty($data)) {
    // Output pesan sebelum header() akan menyebabkan masalah, pastikan tidak ada output sebelumnya
    ob_clean();

    $_SESSION['id_user'] = $data['id_user'];
    $_SESSION['username'] = $data['username'];
    $_SESSION['password'] = $data['password'];
    $_SESSION['nama_pengguna'] = $data['nama_pengguna'];

    var_dump($_SESSION); // Cek nilai sesi

    // arahkan ke halaman admin
    header('location: admin.php');
    exit(); // Pastikan keluar dari skrip setelah mengarahkan header
} else {
    echo "<script>
            alert('Maaf, Login Gagal, Pastikan Username dan Password Anda Benar!');
            document.location='index.php';
          </script>";
    exit(); // Pastikan keluar dari skrip setelah menampilkan pesan
}
?>
